"use strict";

namespace core{

}